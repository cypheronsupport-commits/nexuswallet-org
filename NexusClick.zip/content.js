/* ============================================
   AutoClick Pro — Content Script
   Runs on every web page
   ============================================ */

(() => {
  // Guard against double-injection
  if (window.__acpLoaded) return;
  window.__acpLoaded = true;

  let autoClickTimer = null;
  let isAutoClicking = false;
  let clickCount = 0;
  let maxClicks = 0;
  let currentSettings = null;

  let isPicking = false;
  let isRecording = false;
  let lastActionTime = null;
  let highlightEl = null;

  let isPlaying = false;
  let playAbort = false;

  // ---- Message Listener ----
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      switch (msg.action) {
        case 'startAutoClick':
          startAutoClick(msg.settings);
          break;
        case 'stopAutoClick':
          stopAutoClick();
          break;
        case 'toggleAutoClick':
          if (isAutoClicking) {
            stopAutoClick();
            chrome.runtime.sendMessage({ action: 'autoClickStopped' });
          } else if (currentSettings) {
            startAutoClick(currentSettings);
          }
          break;
        case 'startPicking':
          startPicking();
          break;
        case 'startRecording':
          startRecording();
          break;
        case 'stopRecording':
          stopRecording();
          break;
        case 'playRecording':
          playRecording(msg.actions, msg.speed, msg.loops);
          break;
        case 'stopPlayback':
          playAbort = true;
          break;
        case 'ping':
          // Used to check if content script is loaded
          break;
      }
    } catch (e) {
      console.error('AutoClick Pro:', e);
    }
    sendResponse({ ok: true });
    return false;
  });

  // ============================================
  // AUTO CLICK
  // ============================================
  function startAutoClick(settings) {
    stopAutoClick();

    currentSettings = settings;
    isAutoClicking = true;
    clickCount = 0;
    maxClicks = settings.repeatCount || 0;

    const performClick = () => {
      if (!isAutoClicking) return;

      let target;
      if (settings.targetSelector) {
        target = document.querySelector(settings.targetSelector);
        if (!target) {
          stopAutoClick();
          chrome.runtime.sendMessage({ action: 'autoClickStopped' });
          return;
        }
      } else {
        target = document.activeElement || document.body;
      }

      const rect = target.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;

      const eventOpts = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: x,
        clientY: y,
      };

      switch (settings.clickType) {
        case 'single':
          target.dispatchEvent(new MouseEvent('mousedown', eventOpts));
          target.dispatchEvent(new MouseEvent('mouseup', eventOpts));
          target.dispatchEvent(new MouseEvent('click', eventOpts));
          break;
        case 'double':
          target.dispatchEvent(new MouseEvent('click', eventOpts));
          target.dispatchEvent(new MouseEvent('click', eventOpts));
          target.dispatchEvent(new MouseEvent('dblclick', eventOpts));
          break;
        case 'right':
          target.dispatchEvent(new MouseEvent('contextmenu', { ...eventOpts, button: 2 }));
          break;
      }

      showClickRipple(x, y);

      clickCount++;
      try {
        chrome.runtime.sendMessage({ action: 'clickPerformed', count: clickCount });
      } catch (e) { /* popup/panel may be closed */ }

      if (maxClicks > 0 && clickCount >= maxClicks) {
        stopAutoClick();
        try {
          chrome.runtime.sendMessage({ action: 'autoClickStopped' });
        } catch (e) {}
      }
    };

    const scheduleNext = () => {
      if (!isAutoClicking) return;

      const delay = settings.interval + (settings.randomDelay > 0
        ? Math.floor(Math.random() * settings.randomDelay)
        : 0);

      autoClickTimer = setTimeout(() => {
        performClick();
        scheduleNext();
      }, delay);
    };

    // First click immediately
    performClick();
    scheduleNext();
  }

  function stopAutoClick() {
    isAutoClicking = false;
    if (autoClickTimer !== null) {
      clearTimeout(autoClickTimer);
      autoClickTimer = null;
    }
  }

  // ============================================
  // ELEMENT PICKER
  // ============================================
  function startPicking() {
    isPicking = true;
    createHighlightOverlay();

    document.addEventListener('mousemove', onPickerMove, true);
    document.addEventListener('click', onPickerClick, true);
    document.addEventListener('keydown', onPickerKey, true);
    document.body.style.cursor = 'crosshair';
  }

  function stopPicking() {
    isPicking = false;
    removeHighlightOverlay();
    document.removeEventListener('mousemove', onPickerMove, true);
    document.removeEventListener('click', onPickerClick, true);
    document.removeEventListener('keydown', onPickerKey, true);
    document.body.style.cursor = '';
  }

  function onPickerMove(e) {
    if (!isPicking) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el && el !== highlightEl && !el.classList.contains('acp-overlay')) {
      updateHighlight(el);
    }
  }

  function onPickerClick(e) {
    if (!isPicking) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (el && !el.classList.contains('acp-overlay')) {
      const selector = generateSelector(el);
      try {
        chrome.runtime.sendMessage({ action: 'elementPicked', selector });
      } catch (e) {}
    }

    stopPicking();
  }

  function onPickerKey(e) {
    if (e.key === 'Escape') {
      stopPicking();
    }
  }

  function createHighlightOverlay() {
    removeHighlightOverlay();
    highlightEl = document.createElement('div');
    highlightEl.className = 'acp-overlay acp-highlight';
    document.body.appendChild(highlightEl);
  }

  function removeHighlightOverlay() {
    if (highlightEl) {
      highlightEl.remove();
      highlightEl = null;
    }
  }

  function updateHighlight(el) {
    if (!highlightEl) return;
    const rect = el.getBoundingClientRect();
    highlightEl.style.left = rect.left + window.scrollX + 'px';
    highlightEl.style.top = rect.top + window.scrollY + 'px';
    highlightEl.style.width = rect.width + 'px';
    highlightEl.style.height = rect.height + 'px';
  }

  // ============================================
  // SELECTOR GENERATOR
  // ============================================
  function generateSelector(el) {
    if (el.id) {
      return '#' + CSS.escape(el.id);
    }

    if (el.classList.length > 0) {
      const classes = Array.from(el.classList)
        .filter(c => !c.startsWith('acp-'))
        .map(c => '.' + CSS.escape(c))
        .join('');
      if (classes && document.querySelectorAll(classes).length === 1) {
        return classes;
      }
    }

    for (const attr of el.attributes) {
      if (attr.name.startsWith('data-') && attr.value) {
        const sel = `[${attr.name}="${CSS.escape(attr.value)}"]`;
        if (document.querySelectorAll(sel).length === 1) {
          return sel;
        }
      }
    }

    const parts = [];
    let current = el;
    while (current && current !== document.body) {
      let part = current.tagName.toLowerCase();
      if (current.id) {
        parts.unshift('#' + CSS.escape(current.id));
        break;
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) {
          const index = siblings.indexOf(current) + 1;
          part += `:nth-of-type(${index})`;
        }
      }
      parts.unshift(part);
      current = parent;
    }

    return parts.join(' > ');
  }

  // ============================================
  // RECORDING
  // ============================================
  function startRecording() {
    stopRecording();
    isRecording = true;
    lastActionTime = Date.now();
    chrome.storage.local.set({ isRecordingActive: true });
    document.addEventListener('click', onRecordClick, true);
  }

  function stopRecording() {
    isRecording = false;
    chrome.storage.local.set({ isRecordingActive: false });
    document.removeEventListener('click', onRecordClick, true);
  }

  // Auto-resume recording after page navigation
  chrome.storage.local.get('isRecordingActive', (data) => {
    if (data.isRecordingActive) {
      isRecording = true;
      lastActionTime = Date.now();
      document.addEventListener('click', onRecordClick, true);
    }
  });

  function onRecordClick(e) {
    if (!isRecording) return;
    if (e.target.classList && e.target.classList.contains('acp-overlay')) return;
    // Record immediately — no debounce, no delay
    recordAction('click', e);
  }

  function recordAction(type, e) {
    const now = Date.now();
    const delay = now - lastActionTime;
    lastActionTime = now;

    const target = e.target;
    const selector = generateSelector(target);

    const actionData = {
      type,
      x: Math.round(e.clientX),
      y: Math.round(e.clientY),
      selector,
      delay: delay > 50 ? delay : 0,
      timestamp: now,
    };

    try {
      chrome.runtime.sendMessage({ action: 'actionRecorded', actionData });
    } catch (e) {}
  }

  // ============================================
  // PLAYBACK
  // ============================================
  async function playRecording(actions, speed = 1, loops = 1) {
    isPlaying = true;
    playAbort = false;

    for (let loop = 0; loop < loops; loop++) {
      for (let i = 0; i < actions.length; i++) {
        if (playAbort) {
          isPlaying = false;
          try { chrome.runtime.sendMessage({ action: 'playbackDone' }); } catch (e) {}
          return;
        }

        const action = actions[i];

        if (action.delay > 0 && i > 0) {
          await sleep(action.delay / speed);
        }

        if (playAbort) {
          isPlaying = false;
          try { chrome.runtime.sendMessage({ action: 'playbackDone' }); } catch (e) {}
          return;
        }

        let target = null;
        if (action.selector) {
          target = document.querySelector(action.selector);
        }
        if (!target) {
          target = document.elementFromPoint(action.x, action.y);
        }

        if (target) {
          const rect = target.getBoundingClientRect();
          const x = rect.left + rect.width / 2;
          const y = rect.top + rect.height / 2;
          const eventOpts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };

          if (action.type === 'dblclick') {
            target.dispatchEvent(new MouseEvent('click', eventOpts));
            target.dispatchEvent(new MouseEvent('click', eventOpts));
            target.dispatchEvent(new MouseEvent('dblclick', eventOpts));
          } else {
            target.dispatchEvent(new MouseEvent('mousedown', eventOpts));
            target.dispatchEvent(new MouseEvent('mouseup', eventOpts));
            target.dispatchEvent(new MouseEvent('click', eventOpts));
          }

          showClickRipple(x, y);
        }
      }
    }

    isPlaying = false;
    try {
      chrome.runtime.sendMessage({ action: 'playbackDone' });
    } catch (e) {}
  }

  // ============================================
  // VISUAL FEEDBACK
  // ============================================
  function showClickRipple(x, y) {
    const ripple = document.createElement('div');
    ripple.className = 'acp-overlay acp-ripple';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    document.body.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
})();
