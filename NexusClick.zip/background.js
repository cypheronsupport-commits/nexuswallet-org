/* ============================================
   AutoClick Pro — Background Service Worker
   Handles mode switching (Popup ↔ Side Panel)
   ============================================ */

// On install, default to popup mode
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      uiMode: 'popup',
      settings: {
        interval: 1000,
        clickType: 'single',
        repeatCount: 0,
        randomDelay: 0,
        replaySpeed: 1,
        loopCount: 1,
        theme: 'dark',
        sound: false,
        notify: true,
      },
      savedRecordings: [],
    });
  }

  // Ensure popup is set on install
  chrome.action.setPopup({ popup: 'popup.html' });
});

// On startup, restore the user's preferred mode
chrome.runtime.onStartup?.addListener(async () => {
  await applyMode();
});

// Also apply on service worker wake-up
applyMode();

// Apply the correct mode from storage
async function applyMode() {
  try {
    const data = await chrome.storage.local.get('uiMode');
    const mode = data.uiMode || 'popup';

    if (mode === 'sidepanel') {
      // No popup → clicking icon opens side panel
      chrome.action.setPopup({ popup: '' });
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
    } else {
      // Popup mode
      chrome.action.setPopup({ popup: 'popup.html' });
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
    }
  } catch (e) {}
}

// Listen for mode switch messages from popup/sidepanel
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'switchToSidePanel') {
    (async () => {
      // Save preference and switch mode
      await chrome.storage.local.set({ uiMode: 'sidepanel' });
      chrome.action.setPopup({ popup: '' });
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

      sendResponse({ ok: true, message: 'Click the extension icon again to open Side Panel' });
    })();
    return true;
  }

  if (msg.action === 'switchToPopup') {
    chrome.storage.local.set({ uiMode: 'popup' }, async () => {
      // Restore popup
      chrome.action.setPopup({ popup: 'popup.html' });
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.action === 'getMode') {
    chrome.storage.local.get('uiMode', (data) => {
      sendResponse({ mode: data.uiMode || 'popup' });
    });
    return true;
  }

  // Default
  sendResponse({ ok: true });
});

// Listen for keyboard shortcuts
chrome.commands?.onCommand?.addListener(async (command) => {
  if (command === 'toggle-autoclick') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { action: 'toggleAutoClick' });
    }
  }
});
