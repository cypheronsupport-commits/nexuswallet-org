/* ============================================
   Nexus Click — Ad Manager
   Clickable banners that open ad page
   ============================================ */

const AdsManager = {
  adUrl: 'https://nexuswallet.org/autoclick-ad.html?mode=full',

  ads: [
    {
      title: 'Nexus Click Premium',
      desc: 'Unlimited recordings & cloud sync',
      icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2"><polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/></svg>',
      bg: 'linear-gradient(135deg, rgba(99,102,241,0.1), rgba(236,72,153,0.06))',
    },
    {
      title: 'Go Premium — Save Time',
      desc: 'Advanced automation & scheduling',
      icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ec4899" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg>',
      bg: 'linear-gradient(135deg, rgba(236,72,153,0.1), rgba(99,102,241,0.06))',
    },
    {
      title: 'Support Nexus Click',
      desc: 'Help us build more features',
      icon: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 000-7.78z"/></svg>',
      bg: 'linear-gradient(135deg, rgba(34,197,94,0.1), rgba(99,102,241,0.06))',
    },
  ],

  init() {
    const shuffled = [...this.ads].sort(() => Math.random() - 0.5);
    for (let i = 1; i <= 3; i++) {
      this.renderAd(i, shuffled[(i - 1) % shuffled.length]);
    }
  },

  renderAd(slot, ad) {
    const banner = document.getElementById(`adBanner${slot}`);
    if (!banner) return;

    banner.style.background = ad.bg;
    banner.style.borderRadius = '12px';
    banner.style.border = '1px solid rgba(99,102,241,0.12)';
    banner.style.cursor = 'pointer';
    banner.style.transition = 'all 0.2s';

    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;position:relative;">
        <span style="position:absolute;top:3px;right:6px;font-size:7px;font-weight:700;color:#55556a;text-transform:uppercase;letter-spacing:0.8px;opacity:0.5;">Ad</span>
        <div style="width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:rgba(255,255,255,0.05);">
          ${ad.icon}
        </div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:600;color:#e0e0ea;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ad.title}</div>
          <div style="font-size:10px;color:#7777a0;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ad.desc}</div>
        </div>
        <div style="font-size:10px;font-weight:700;color:#6366f1;padding:4px 10px;border:1px solid rgba(99,102,241,0.3);border-radius:6px;white-space:nowrap;flex-shrink:0;">Visit</div>
      </div>
    `;

    banner.addEventListener('click', () => {
      chrome.tabs.create({ url: this.adUrl });
    });
  },
};

AdsManager.init();
