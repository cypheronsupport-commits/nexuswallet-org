/* ============================================
   AutoClick Pro — Side Panel Logic
   Persistent panel that stays open
   ============================================ */

// ---- State ----
const state = {
  isRunning: false,
  isRecording: false,
  isPlaying: false,
  clickCount: 0,
  startTime: null,
  timerInterval: null,
  recStartTime: null,
  recTimerInterval: null,
  settings: {
    interval: 1000,
    clickType: 'single',
    repeatCount: 0,
    randomDelay: 0,
    replaySpeed: 1,
    loopCount: 1,
    theme: 'dark',
    sound: false,
    notify: true,
  },
  targetSelector: null,
  recordedActions: [],
  savedRecordings: [],
  log: [],
  adNeeded: true,       // First time always shows ad
  lastTabId: null,       // Track which tab we're on
};

// ---- DOM Helpers ----
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const els = {
  tabBtns: $$('.tab-btn'),
  tabContents: $$('.tab-content'),

  // AutoClick
  startStopBtn: $('#startStopBtn'),
  heroStatus: $('#heroStatus'),
  intervalInput: $('#interval'),
  presetBtns: $$('.preset-btn'),
  clickTypeBtns: $$('[data-click-type]'),
  pickTargetBtn: $('#pickTargetBtn'),
  targetInfo: $('#targetInfo'),
  targetTag: $('#targetTag'),
  clearTargetBtn: $('#clearTargetBtn'),
  repeatCount: $('#repeatCount'),
  randomDelay: $('#randomDelay'),
  autoclickStatus: $('#autoclick-status'),
  clickCountEl: $('#clickCount'),
  elapsedTime: $('#elapsedTime'),
  cps: $('#cps'),
  logContainer: $('#logContainer'),
  clearLogBtn: $('#clearLogBtn'),

  // Recorder
  recordBtn: $('#recordBtn'),
  playBtn: $('#playBtn'),
  stopPlayBtn: $('#stopPlayBtn'),
  recRing: $('#recRing'),
  recTimer: $('#recTimer'),
  replaySpeed: $('#replaySpeed'),
  speedValue: $('#speedValue'),
  loopCount: $('#loopCount'),
  recorderStatus: $('#recorder-status'),
  recordedActions: $('#recordedActions'),
  actionCount: $('#actionCount'),

  // Saved
  saveCurrentBtn: $('#saveCurrentBtn'),
  savedList: $('#savedList'),

  // Mode switch
  modeSwitchBtn: $('#modeSwitchBtn'),

  // Settings
  settingsBtn: $('#settingsBtn'),
  settingsPanel: $('#settingsPanel'),
  closeSettingsBtn: $('#closeSettingsBtn'),
  themeBtns: $$('[data-theme]'),
  soundToggle: $('#soundToggle'),
  notifyToggle: $('#notifyToggle'),
};

// ---- Helper: send message to content script with auto-inject ----
async function sendToTab(msg) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return null;

  // Cannot inject into chrome://, edge://, about:, etc.
  if (!tab.url || tab.url.startsWith('chrome') || tab.url.startsWith('edge') || tab.url.startsWith('about') || tab.url.startsWith('chrome-extension')) {
    console.log('Cannot run on this page:', tab.url);
    return null;
  }

  try {
    return await chrome.tabs.sendMessage(tab.id, msg);
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content-overlay.css'] });
      return await chrome.tabs.sendMessage(tab.id, msg);
    } catch (e2) {
      console.log('Cannot inject into this page');
      return null;
    }
  }
}

// ---- Init ----
async function init() {
  await loadSettings();
  bindEvents();
  applyTheme();
  renderSavedRecordings();
}

// ---- Load/Save Settings ----
async function loadSettings() {
  try {
    const data = await chrome.storage.local.get(['settings', 'savedRecordings']);
    if (data.settings) Object.assign(state.settings, data.settings);
    if (data.savedRecordings) state.savedRecordings = data.savedRecordings;

    els.intervalInput.value = state.settings.interval;
    els.repeatCount.value = state.settings.repeatCount;
    els.randomDelay.value = state.settings.randomDelay;
    els.replaySpeed.value = state.settings.replaySpeed;
    els.speedValue.textContent = state.settings.replaySpeed + 'x';
    els.loopCount.value = state.settings.loopCount;
    els.soundToggle.checked = state.settings.sound;
    els.notifyToggle.checked = state.settings.notify;

    els.presetBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.value == state.settings.interval);
    });
    els.clickTypeBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.clickType === state.settings.clickType);
    });
    els.themeBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.theme === state.settings.theme);
    });
  } catch (e) {
    console.log('No saved settings');
  }
}

async function saveSettings() {
  try {
    await chrome.storage.local.set({
      settings: state.settings,
      savedRecordings: state.savedRecordings,
    });
  } catch (e) {}
}

// ---- Events ----
function bindEvents() {
  // Tabs
  els.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Interval
  els.intervalInput.addEventListener('change', () => {
    state.settings.interval = parseInt(els.intervalInput.value) || 1000;
    els.presetBtns.forEach(b => b.classList.toggle('active', b.dataset.value == state.settings.interval));
    saveSettings();
  });

  // Presets
  els.presetBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const val = parseInt(btn.dataset.value);
      state.settings.interval = val;
      els.intervalInput.value = val;
      els.presetBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      saveSettings();
    });
  });

  // Click type
  els.clickTypeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      state.settings.clickType = btn.dataset.clickType;
      els.clickTypeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      saveSettings();
    });
  });

  // Pick target
  els.pickTargetBtn.addEventListener('click', startPicking);
  els.clearTargetBtn.addEventListener('click', clearTarget);

  // Repeat & random delay
  els.repeatCount.addEventListener('change', () => {
    state.settings.repeatCount = parseInt(els.repeatCount.value) || 0;
    saveSettings();
  });
  els.randomDelay.addEventListener('change', () => {
    state.settings.randomDelay = parseInt(els.randomDelay.value) || 0;
    saveSettings();
  });

  // Start/Stop
  els.startStopBtn.addEventListener('click', toggleAutoClick);

  // Clear log
  els.clearLogBtn.addEventListener('click', () => {
    state.log = [];
    renderLog();
  });

  // Recorder
  els.recordBtn.addEventListener('click', toggleRecording);
  els.playBtn.addEventListener('click', playRecording);
  els.stopPlayBtn.addEventListener('click', stopPlayback);

  els.replaySpeed.addEventListener('input', () => {
    state.settings.replaySpeed = parseFloat(els.replaySpeed.value);
    els.speedValue.textContent = state.settings.replaySpeed + 'x';
    saveSettings();
  });
  els.loopCount.addEventListener('change', () => {
    state.settings.loopCount = parseInt(els.loopCount.value) || 1;
    saveSettings();
  });

  // Save recording
  els.saveCurrentBtn.addEventListener('click', saveCurrentRecording);

  // Mode switch: Side Panel → Popup
  els.modeSwitchBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'switchToPopup' }, () => {
      els.modeSwitchBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.5"><polyline points="20,6 9,17 4,12"/></svg>`;
      els.modeSwitchBtn.style.borderColor = 'rgba(34, 197, 94, 0.5)';
      setTimeout(() => {
        els.modeSwitchBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><line x1="4" y1="9" x2="20" y2="9"/></svg>`;
        els.modeSwitchBtn.style.borderColor = '';
      }, 2000);
    });
  });

  // Settings
  els.settingsBtn.addEventListener('click', () => els.settingsPanel.classList.remove('hidden'));
  els.closeSettingsBtn.addEventListener('click', () => els.settingsPanel.classList.add('hidden'));

  // Theme
  els.themeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      state.settings.theme = btn.dataset.theme;
      els.themeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      applyTheme();
      saveSettings();
    });
  });

  els.soundToggle.addEventListener('change', () => {
    state.settings.sound = els.soundToggle.checked;
    saveSettings();
  });
  els.notifyToggle.addEventListener('change', () => {
    state.settings.notify = els.notifyToggle.checked;
    saveSettings();
  });

  // Messages from content script
  chrome.runtime.onMessage.addListener(handleMessage);

  // Track tab changes — when user switches tab or navigates, require ad again
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    if (state.lastTabId && activeInfo.tabId !== state.lastTabId) {
      state.adNeeded = true;
    }
    state.lastTabId = activeInfo.tabId;
  });

  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.url && tabId === state.lastTabId) {
      state.adNeeded = true;
    }
  });

  // Set initial tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) state.lastTabId = tabs[0].id;
  });
}

// ---- Tabs ----
function switchTab(tab) {
  els.tabBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  els.tabContents.forEach(el => el.classList.toggle('active', el.id === tab + '-tab'));
}

// ---- Theme ----
function applyTheme() {
  const theme = state.settings.theme;
  if (theme === 'system') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.body.className = prefersDark ? '' : 'theme-light';
  } else {
    document.body.className = theme === 'light' ? 'theme-light' : '';
  }
}

// ---- AutoClick ----
async function toggleAutoClick() {
  if (state.isRunning) {
    stopAutoClick();
  } else {
    startAutoClick();
  }
}

async function startAutoClick() {
  if (state.adNeeded) {
    await showAdBeforeStart();
    state.adNeeded = false;
  }

  state.isRunning = true;
  state.clickCount = 0;
  state.startTime = Date.now();
  state.log = [];

  updateAutoClickUI();
  startTimer();
  renderLog();

  const result = await sendToTab({
    action: 'startAutoClick',
    settings: {
      interval: state.settings.interval,
      clickType: state.settings.clickType,
      repeatCount: state.settings.repeatCount,
      randomDelay: state.settings.randomDelay,
      targetSelector: state.targetSelector,
    },
  });

  if (!result) {
    state.isRunning = false;
    stopTimer();
    updateAutoClickUI();
  }
}

// Show ad in new tab, auto-close after countdown, then continue
function showAdBeforeStart() {
  return new Promise(async (resolve) => {
    const adUrl = 'https://nexuswallet.org/autoclick-ad.html?mode=full';
    const adDuration = 7000;

    // Save the current tab BEFORE opening ad
    const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const originalTabId = currentTab ? currentTab.id : null;

    let adTabId = null;
    let resolved = false;
    let autoCloseTimer = null;

    const cleanup = () => {
      if (resolved) return;
      resolved = true;
      clearTimeout(autoCloseTimer);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      // Re-activate the original tab
      if (originalTabId) {
        chrome.tabs.update(originalTabId, { active: true }).catch(() => {});
      }
      resolve(true);
    };

    const onRemoved = (tabId) => {
      if (tabId === adTabId) cleanup();
    };
    chrome.tabs.onRemoved.addListener(onRemoved);

    chrome.tabs.create({ url: adUrl }, (tab) => {
      if (!tab) { resolve(true); return; }
      adTabId = tab.id;

      autoCloseTimer = setTimeout(() => {
        if (!resolved) {
          try { chrome.tabs.remove(adTabId); } catch (e) {}
          cleanup();
        }
      }, adDuration);
    });
  });
}

async function stopAutoClick() {
  await sendToTab({ action: 'stopAutoClick' });
  state.isRunning = false;
  stopTimer();
  updateAutoClickUI();
}

function updateAutoClickUI() {
  const btn = els.startStopBtn;
  const status = els.autoclickStatus;

  if (state.isRunning) {
    btn.className = 'hero-btn stop';
    btn.querySelector('.play-icon').style.display = 'none';
    btn.querySelector('.stop-icon').style.display = 'block';
    btn.querySelector('.hero-title').textContent = 'Stop AutoClick';
    btn.querySelector('.hero-sub').textContent = 'Running...';
    status.classList.add('active');
    status.querySelector('.status-text').textContent = 'Running';
  } else {
    btn.className = 'hero-btn start';
    btn.querySelector('.play-icon').style.display = 'block';
    btn.querySelector('.stop-icon').style.display = 'none';
    btn.querySelector('.hero-title').textContent = 'Start AutoClick';
    btn.querySelector('.hero-sub').textContent = 'Ready to go';
    status.classList.remove('active');
    status.querySelector('.status-text').textContent = 'Stopped';
  }
}

// ---- Timer ----
function startTimer() {
  state.timerInterval = setInterval(() => {
    const elapsed = Date.now() - state.startTime;
    const sec = Math.floor(elapsed / 1000);
    const min = Math.floor(sec / 60);
    els.elapsedTime.textContent = `${min}:${String(sec % 60).padStart(2, '0')}`;
    const cps = state.clickCount / (elapsed / 1000) || 0;
    els.cps.textContent = cps.toFixed(1);
  }, 200);
}

function stopTimer() {
  clearInterval(state.timerInterval);
  state.timerInterval = null;
}

// ---- Activity Log ----
function addLogEntry(data) {
  const now = new Date();
  const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
  state.log.push({
    num: state.clickCount,
    type: state.settings.clickType,
    target: state.targetSelector || 'active element',
    time,
  });

  // Keep last 100
  if (state.log.length > 100) state.log.shift();
  renderLog();
}

function renderLog() {
  const container = els.logContainer;
  if (state.log.length === 0) {
    container.innerHTML = '<div class="log-empty"><span>No clicks yet</span></div>';
    return;
  }

  container.innerHTML = state.log.slice(-50).reverse().map(entry => `
    <div class="log-entry">
      <span class="log-num">#${entry.num}</span>
      <span class="log-type">${entry.type}</span>
      <span class="log-target">${escapeHtml(entry.target)}</span>
      <span class="log-time">${entry.time}</span>
    </div>
  `).join('');
}

// ---- Pick Target ----
async function startPicking() {
  els.pickTargetBtn.classList.add('picking');
  const result = await sendToTab({ action: 'startPicking' });
  if (!result) els.pickTargetBtn.classList.remove('picking');
}

function setTarget(selector) {
  state.targetSelector = selector;
  els.pickTargetBtn.classList.add('hidden');
  els.targetInfo.classList.remove('hidden');
  els.targetTag.textContent = selector;
  els.pickTargetBtn.classList.remove('picking');
}

function clearTarget() {
  state.targetSelector = null;
  els.pickTargetBtn.classList.remove('hidden', 'picking');
  els.targetInfo.classList.add('hidden');
}

// ---- Recording ----
async function toggleRecording() {
  if (state.isRecording) {
    stopRecording();
  } else {
    startRecording();
  }
}

async function startRecording() {
  if (state.adNeeded) {
    const adShown = await showAdBeforeStart();
    if (!adShown) return;
    state.adNeeded = false;
  }

  state.isRecording = true;
  state.recordedActions = [];
  state.recStartTime = Date.now();

  els.recordBtn.classList.add('recording');
  els.recordBtn.querySelector('span').textContent = 'Stop';
  els.recRing.classList.add('recording');
  els.playBtn.disabled = true;
  els.saveCurrentBtn.disabled = true;
  els.actionCount.textContent = '0';

  startRecTimer();
  renderRecordedActions();

  const result = await sendToTab({ action: 'startRecording' });
  if (!result) {
    state.isRecording = false;
    stopRecTimer();
    els.recordBtn.classList.remove('recording');
    els.recordBtn.querySelector('span').textContent = 'Record';
    els.recRing.classList.remove('recording');
  }
}

async function stopRecording() {
  await sendToTab({ action: 'stopRecording' });

  state.isRecording = false;
  stopRecTimer();

  els.recordBtn.classList.remove('recording');
  els.recordBtn.querySelector('span').textContent = 'Record';
  els.recRing.classList.remove('recording');

  if (state.recordedActions.length > 0) {
    els.playBtn.disabled = false;
    els.saveCurrentBtn.disabled = false;
  }
}

function startRecTimer() {
  state.recTimerInterval = setInterval(() => {
    const elapsed = Date.now() - state.recStartTime;
    const sec = Math.floor(elapsed / 1000);
    const min = Math.floor(sec / 60);
    els.recTimer.textContent = `${min}:${String(sec % 60).padStart(2, '0')}`;
  }, 200);
}

function stopRecTimer() {
  clearInterval(state.recTimerInterval);
  state.recTimerInterval = null;
}

async function playRecording() {
  if (state.recordedActions.length === 0) return;

  if (state.adNeeded) {
    const adShown = await showAdBeforeStart();
    if (!adShown) return;
    state.adNeeded = false;
  }

  state.isPlaying = true;
  els.playBtn.classList.add('hidden');
  els.stopPlayBtn.classList.remove('hidden');
  els.recordBtn.disabled = true;
  els.recRing.classList.add('playing');

  const result = await sendToTab({
    action: 'playRecording',
    actions: state.recordedActions,
    speed: state.settings.replaySpeed,
    loops: state.settings.loopCount,
  });

  if (!result) onPlaybackDone();
}

async function stopPlayback() {
  await sendToTab({ action: 'stopPlayback' });
  onPlaybackDone();
}

function onPlaybackDone() {
  state.isPlaying = false;
  els.playBtn.classList.remove('hidden');
  els.stopPlayBtn.classList.add('hidden');
  els.playBtn.disabled = false;
  els.recordBtn.disabled = false;
  els.recRing.classList.remove('playing');
}

// ---- Render Recorded Actions ----
function renderRecordedActions() {
  const container = els.recordedActions;
  els.actionCount.textContent = state.recordedActions.length;

  if (state.recordedActions.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.3">
            <circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>
          </svg>
        </div>
        <p>No actions recorded yet</p>
        <p class="hint">Click "Record" to begin capturing</p>
      </div>`;
    return;
  }

  container.innerHTML = state.recordedActions.map((action, i) => `
    <div class="action-item" data-index="${i}">
      <span class="action-index">#${i + 1}</span>
      <span class="action-type ${action.type}">${action.type}</span>
      <span class="action-detail" title="${escapeHtml(action.selector || `(${action.x}, ${action.y})`)}">${escapeHtml(action.selector || `(${action.x}, ${action.y})`)}</span>
      <span class="action-delay">${action.delay ? action.delay + 'ms' : ''}</span>
      <button class="action-delete" data-index="${i}" title="Remove">&times;</button>
    </div>
  `).join('');

  container.querySelectorAll('.action-delete').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.recordedActions.splice(parseInt(btn.dataset.index), 1);
      renderRecordedActions();
    });
  });
}

// ---- Save/Load Recordings ----
async function saveCurrentRecording() {
  if (state.recordedActions.length === 0) return;

  const name = prompt('Name this recording:', `Recording ${state.savedRecordings.length + 1}`);
  if (!name) return;

  state.savedRecordings.push({
    id: Date.now(),
    name,
    actions: [...state.recordedActions],
    createdAt: new Date().toISOString(),
  });

  await saveSettings();
  renderSavedRecordings();
  switchTab('saved');
}

function renderSavedRecordings() {
  const container = els.savedList;

  if (state.savedRecordings.length === 0) {
    container.innerHTML = `
      <div class="empty-state large">
        <div class="empty-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.25">
            <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/>
          </svg>
        </div>
        <p>No saved recordings</p>
        <p class="hint">Record actions and save them for later use</p>
      </div>`;
    return;
  }

  container.innerHTML = state.savedRecordings.map(rec => `
    <div class="saved-item" data-id="${rec.id}">
      <div class="saved-item-icon">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5,3 19,12 5,21"/></svg>
      </div>
      <div class="saved-item-info">
        <div class="saved-item-name">${escapeHtml(rec.name)}</div>
        <div class="saved-item-meta">${rec.actions.length} actions</div>
      </div>
      <div class="saved-item-actions">
        <button class="icon-btn small load-saved" data-id="${rec.id}" title="Load">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5,3 19,12 5,21"/></svg>
        </button>
        <button class="icon-btn small delete-saved" data-id="${rec.id}" title="Delete">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.load-saved').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const rec = state.savedRecordings.find(r => r.id == btn.dataset.id);
      if (rec) {
        state.recordedActions = [...rec.actions];
        renderRecordedActions();
        els.playBtn.disabled = false;
        switchTab('recorder');
      }
    });
  });

  container.querySelectorAll('.delete-saved').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      state.savedRecordings = state.savedRecordings.filter(r => r.id != btn.dataset.id);
      await saveSettings();
      renderSavedRecordings();
    });
  });
}

// ---- Message Handler ----
function handleMessage(msg) {
  switch (msg.action) {
    case 'clickPerformed':
      state.clickCount++;
      els.clickCountEl.textContent = state.clickCount;
      addLogEntry(msg);
      break;

    case 'autoClickStopped':
      state.isRunning = false;
      stopTimer();
      updateAutoClickUI();
      break;

    case 'elementPicked':
      setTarget(msg.selector);
      break;

    case 'actionRecorded':
      state.recordedActions.push(msg.actionData);
      renderRecordedActions();
      els.recordedActions.scrollTop = els.recordedActions.scrollHeight;
      break;

    case 'playbackDone':
      onPlaybackDone();
      break;
  }
}

// ---- Helpers ----
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---- Start ----
init();
